// E2E test of the optimized exporter against the previously-stalling long session.
const api = require('./out/api');
const { exportSessionToZip } = require('./out/exporter');
const fs = require('fs');

(async () => {
  const t0 = Date.now();
  const auth = await api.login(process.env.DAO_TEST_EMAIL, process.env.DAO_TEST_PASSWORD);
  console.log('login ok, org=', auth.orgId, ((Date.now() - t0) / 1000).toFixed(1) + 's');

  const devinId = 'devin-10d000406c9b4fa59312a7a0ecd20e88';
  const t1 = Date.now();
  const buf = await exportSessionToZip(auth, devinId, '四个插件进度缺陷分析修复', (msg) => {
    console.log('  [progress]', msg);
  });
  const secs = ((Date.now() - t1) / 1000).toFixed(1);
  fs.writeFileSync('test_long_session.zip', buf);
  console.log(`EXPORT OK: ${(buf.length / 1048576).toFixed(1)} MB in ${secs}s`);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
